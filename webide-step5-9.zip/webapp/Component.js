sap.ui.define(["sap/ui/core/UIComponent",
            "sap/ui/model/json/JSONModel",
            "sap/ui/model/resource/ResourceModel"],
    function(UIComponent, JSONModel, ResourceModel){
   return UIComponent.extend("demo.Component",{
       init: function(){
           UIComponent.prototype.init.apply(this, arguments);
           
            // JSON Data
            var oData={
		        "recipient":{
		            "name":"world"   
		        }  
		      };
		      // Create Model Object- resource model
		      var oModel=new JSONModel(oData);
		      
		      // set model to the view
		      this.setModel(oModel);
		      
		      // create the i18n model object
		      var i18nModel=new ResourceModel({
		          bundleName:"demo.i18n.i18n"
		      });
		      
		      // set the i18n model to the view object
		      this.setModel(i18nModel,"i18n");
       },
       
       metadata:{
           "interfaces" : ["sap.ui.core.IAsyncContentCreation"],
           "rootView" : {
               "viewName" : "demo.view.App",
               "type" : "XML",
               "id" : "App"
           }
       }
   });
});