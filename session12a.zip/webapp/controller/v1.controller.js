sap.ui.define(["sap/ui/core/mvc/Controller"],
        function(Controller){
            return Controller.extend("jerry.controller.v1",{
                onButton: function(oevnt){
                    var btnId=oevnt.getSource().getId();
                    var str=sap.ui.getCore().byId(btnId).getText();
                    var btn1Id=sap.ui.getCore().byId("idBtn1");
                    btn1Id.attachPress(this.onButton1);
                    alert("Not written any code on this" + str + "event");
                },
                
                onButton1: function(oevnt){
                    var oinpValue=sap.ui.getCore().byId("idInp");
                    alert('This function applied from button'+ oinpValue.getValue());
                }
            });
        });