sap.ui.jsview("jerry.view.v1",{
   getControllerName: function(){
       return "jerry.controller.v1";
   },
   createContent: function(oController){
       var oBtn = new sap.m.Button("idBtn",{
           text:"Button",
           press:[oController.onButton,oController]
       });
       
       var oBtn1=new sap.m.Button("idBtn1",{
            text:"Button1"
       });
       var oInpt=new sap.m.Input("idInp",{
           
       });
       return [oBtn, oInpt, oBtn1];
   }
});