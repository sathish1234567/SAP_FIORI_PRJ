sap.ui.define(["sap/ui/core/mvc/Controller"],
   function(Controller){
	"use strict";
   return Controller.extend("jerry.controller.v1",{
    onButton: function(oevnt){
        alert("clicked on button");
    },
    onButton1: function(oevnt){
        alert("clicked on button1");
    }
   });
});