sap.ui.jsview("jerry.view.V1", {
	getControllerName: function() {
		return "jerry.controller.V1";
	},
	createContent: function(oController) {
		var oBtn = new sap.m.Button("idBtn", {
			text: "test",
			press: [oController.oTest, oController]
		});
		var oBtn1 = new sap.m.Button("idBtn1",{
		   text:"apply" 
		});
		var oInp = new sap.m.Input("idInp", {
// 			vlueHelpOnly: "true",
// 			showValueHelp: "true",
// 			editable: "true",
// 			enabled: "true",
// 			valueHelpRequest: oController.onValuHelp
		});
		var oPge = new sap.m.Page("idPage", {
			showFooter: true,
			showHeader: true,
			showNavButton: true,
			title: "testing",
			content: [oBtn, oBtn1]
		});

		var oApp = new sap.m.App("idApp", {
			initialPage: "idPage"
		});

		oApp.addPage(oPge);
		return oApp;
	}
});