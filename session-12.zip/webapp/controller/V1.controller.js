sap.ui.define(["sap/ui/core/mvc/Controller"],
    function(Controller){
        return Controller.extend("jerry.controller.V1",{
            oTest: function(oEvnt){
                var oId = oEvnt.getSource().getId();
                var obtn1 = sap.ui.getCore().byId("idBtn1");
                obtn1.attachPress(this.apply);
                alert('pressd' + ' ' + oId);
            },
            onValueHelp: function(oEvnt){
                
            },
            apply: function(oEvnt){
                alert('apply')
            }
        });
        
    });