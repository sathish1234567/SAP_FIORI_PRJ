sap.ui.define(["sap/ui/core/mvc/Controller",
                "sap/m/MessageToast",
                "sap/ui/model/json/JSONModel",
                "sap/ui/model/resource/ResourceModel"],
	function(Controller, MessgeToast, JSONModel, ResourceModel) {
		"use strict";
		return Controller.extend("demo.controller.App", {
// 		    onInit: function(){
// 		      var oData={
// 		        "recipient":{
// 		            "name":"world"   
// 		        }  
// 		      };
// 		      var oModel=new JSONModel(oData);
// 		      this.getView().setModel(oModel);
		      
// 		      var i18nModel=new ResourceModel({
// 		          bundleName:"demo.i18n.i18n"
// 		      });
// 		      this.getView().setModel(i18nModel,"i18n");
// 		    },
// 			onPress: function() {
// 			  var obundle = this.getView().getModel("i18n").getResourceBundle();
// 			  var sRepnt = this.getView().getModel().getProperty("/recipient/name");
// 			  var sMsg = obundle.getText("helloMsg", [sRepnt]);
// 	          MessgeToast.show(sMsg);  
// 				// alert("Hello world");
// 			}
		});
	});