sap.ui.jsview("jerry.view.Jv1",{
    getControllerName: function(){
        return "jerry.controller.Jv1";     
    },
    
//     	createContent: function (oController) {
// 		var oInput = new sap.m.Input("idInp");
// 		var oBtn = new sap.m.Button("idBtn",{
// 				text : "killMe",
// 				press: oController.press
// 		});
// 		return[oBtn,oInput];
//     	}
    createContent: function(oController){
        
        var oPage= new sap.m.Page("idPage",{
            title: "Testing title",
            content: [new sap.m.Button("idBtn",{
              text:"press",
              press:[oController.press]
            })
            ]
        });
        
        var app = sap.m.App("idApp",{
            initialPage: "oPage" 
        });
        
        	app.addPage(oPage);
		return app;
        
    }
    
    
});