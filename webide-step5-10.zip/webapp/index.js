sap.ui.define(["sap/ui/core/mvc/XMLView",
		       "sap/ui/core/ComponentContainer"
	],
	function (XMLView, ComponentContainer){
	    "use strict";
	    
	    new ComponentContainer({
	       name : "demo",
	       settings: {
	           id : "walkthrough"
	       },
	       async : true
	    }).placeAt("content");
	// unanomus function calling itself only.
// 	function(XMLView) {
// 		"use strict";
// 		XMLView.create({
// 			viewName: "demo.view.App"
// 		}).then(function(oView) {
// 			oView.placeAt("content");
// 		});
// 		new view({
// 			viewName: "demo.view.App",
// 			controller: "demo.view.App",
// 			type: sap.ui.core.mvc.ViewType.XML,
// 			async: true
// 		}).loaded().then(function(oView) {
// 			// the instance is available in the callback function
// 			oView.placeAt("content");
// 		});
	});