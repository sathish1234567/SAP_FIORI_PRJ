sap.ui.define(["sap/ui/core/mvc/Controller",
                "sap/m/MessageToast",
                "sap/ui/model/json/JSONModel"],
	function(Controller, MessgeToast, JSONModel) {
		"use strict";
		return Controller.extend("demo.controller.App", {
		    onInit: function(){
		      var oData={
		        "recipient":{
		            "name":"world"   
		        }  
		      };
		      var oModel=new JSONModel(oData);
		      this.getView().setModel(oModel);
		    },
			onPress: function() {
	          MessgeToast.show("Hello World");  
				// alert("Hello world");
			}
		});
	});