sap.ui.define(["sap/ui/core/mvc/Controller",
                "sap/m/MessageToast"],
	function(Controller, MessgeToast) {
		"use strict";
		return Controller.extend("demo.controller.App", {
			onPress: function() {
	          MessgeToast.show("Hello World");  
				// alert("Hello world");
			}
		});
	});