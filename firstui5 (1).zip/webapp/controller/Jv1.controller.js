sap.ui.define(["sap/ui/core/mvc/Controller"],
    function(Controller){
        "usestrict";
        
        return Controller.extend("jerry.controller.Jv1",{
            press: function(oEvnt){
                var oBtn = oEvnt.getSource().getId();
                var oBtn1 = sap.ui.getCore().byId(oBtn);
                oBtn1.setText("HI.. don't do mistkes");
            }
        });
    
});